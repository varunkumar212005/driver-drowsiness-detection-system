# AI detection module

Place the tested Python modules here (for example, facial-landmark analysis, EAR/MAR calculations, head-pose logic, and YOLO phone detection).

Document each script's purpose, inputs, outputs, and run command. Do not add placeholder code as if it were a working detector.
