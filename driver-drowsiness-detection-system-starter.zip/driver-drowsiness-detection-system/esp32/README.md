# ESP32 firmware

Place the tested Arduino IDE sketch (`.ino`) here. Document the board selection, pin mapping, sensor wiring, serial message format, and power requirements. Verify all voltage levels before connecting hardware.
