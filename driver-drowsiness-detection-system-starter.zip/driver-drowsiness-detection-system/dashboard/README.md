# Flask dashboard

Place the Flask application, HTML templates, CSS, JavaScript, and dashboard data handling here. Document the actual start command and required configuration after integration.
