# Screenshots

Add genuine screenshots of the working dashboard, AI detections, and hardware prototype. Use images that do not expose private information.
