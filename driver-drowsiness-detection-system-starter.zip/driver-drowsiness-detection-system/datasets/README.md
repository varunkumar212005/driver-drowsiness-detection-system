# Datasets

Keep dataset descriptions, source URLs, licenses, and preparation scripts here. Avoid committing large datasets or personal / identifiable recordings. Check each dataset's license before use.
