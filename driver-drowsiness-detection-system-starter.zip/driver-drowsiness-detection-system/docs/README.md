# Documentation

Add the approved project synopsis, report, architecture diagram, flowchart, literature survey, references, and presentation. Remove personal information that should not be public before committing files.
