# Model files

Document model name, version, training source, labels, evaluation metrics, and download instructions. Large model weights may require Git LFS or a release asset instead of a normal Git commit.
